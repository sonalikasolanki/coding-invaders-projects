
// import { Formik, Form, Field } from "formik";
// import { Link, useParams } from "react-router-dom";

// function Newtask() {
//     const { tasktodo } = useParams();
//     let { email } = useParams();

//     // Define an initial form values object
//     const initialValues = {
//         task: tasktodo || "",  
//         deadline: "",         
//         description: "",
//         priority: false,
//         tag:"",       
       
//     };
//     const handleSave = (values) => {
//             // Handle task creation or update here
//             if (type === 'create') {
//               onCreate(values);
//             } else if (type === 'update') {
//               onUpdate(values);
//             }
//             toggle();
//           };

//     return (
//         <div className="main">
//             <div className="task-container">
//                 <h3 className='formik-h3'>CREATE TASK</h3>
//                 <Formik initialValues={task || initialValues}
//       validationSchema={validationSchema}
//        onSubmit={handleSave}>
//                     {/* Rest of your form code */}
//                 </Formik>
//             </div>
//         </div>
//     )
// }

// export default Newtask;
import './../styles/Newtask.css';
import { Formik, Form, Field } from "formik";
import { Link, useParams } from "react-router-dom";

function Newtask() {
    const { tasktodo } = useParams();
    let { email } = useParams();

    // Define an initial form values object
    const initialValues = {
        task: tasktodo || "",  
        deadline: " ",         
        description: "",
        priority: false,      
      
    };

    
    const handleSubmit = (values) => {
       
        console.log("Form values:", values);
       
    };

    return (
        <div className="main">
            <div className="task-container">
                <h3 className='formik-h3'>CREATE TASK</h3>
                <Formik initialValues={initialValues} onSubmit={handleSubmit}>
                    <Form className="formik-form">
                        <div className='formik-fields'>
                            <label>Task:</label>
                            <Field name="task" type="text" />
                        </div>
                        <div className='formik-fields'>
                            <label>Deadline:</label>
                            <Field name="deadline" type="text" />
                        </div>
                        <div className='formik-fields'>
                            <label>Description:</label>
                            <Field name="description" type="text" />
                        </div>
                        <div className='formik-checkbox'>
                            <label>Priority:</label>
                            <Field name="priority" type="checkbox" />
                        </div>
                        <div className='formik-select'>
                            <label>Tags:</label>
                            <select>
                                <option>Home</option>
                                <option>Work</option>
                                <option>Important</option>
                            </select>
                        </div>
                        <div className='formik-fields'>
                            <label>Image:</label>
                            <Field name="image" type="file" />
                        </div>
                        
                        <div className='formik-btn'>
                            <button className='formik-btn-create' type="submit">Create</button>
                            <Link to={`/home/${email}`}>
                                <button className='formik-btn-cancel'>Cancel</button>
                            </Link>
                        </div>
                    </Form>
                </Formik>
            </div>
        </div>
    );
}

export default Newtask;

