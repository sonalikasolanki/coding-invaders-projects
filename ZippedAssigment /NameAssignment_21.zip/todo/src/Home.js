import React from 'react';
import './Home.css'; 
function Home() {
  return (
    <div>
      <h2>Welcome</h2>
      <p>Login Successful and Welcome!</p>
    </div>
  );
}

export default Home;
