import React from 'react';
import { BrowserRouter , Route, Routes ,Navigate} from 'react-router-dom';
import Login from './Login';
import TodoList from './TodoList';
import Home from './Home';
import NotFound from './NotFound';
function App() {
  return (
    <BrowserRouter>
        <Routes>
        <Route path="/" element={<Navigate to="/login" />} />
          <Route path="/login" element={<Login />} />
          <Route path="/todolist" element={<TodoList />} />
          <Route path="/home" element={<Home />} />
          <Route path="/*" element={<NotFound />} />
        </Routes>
    </BrowserRouter>
  );
}
export default App;


